from setuptools import setup, find_packages

setup(
    name="modules",
    version="0.1",
    description="project second task python course",
    author="alejandra",
    author_email="kblmrtnz@gmail.com",
    url="https://github.com/Kaybel/python_course",
    packages=find_packages(),
    install_requires=[
        'setuptools',
        'wheel',
    ],
)
